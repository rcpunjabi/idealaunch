import { NextResponse } from 'next/server';
import { generateCode } from '@/lib/claude';
import { createRepoAndPushCode } from '@/lib/github';
import { deployToVercel } from '@/lib/vercel';
import { getServiceSupabase } from '@/lib/supabase';

// This runs async — it kicks off the build and returns immediately
export async function POST(request) {
  const { projectId } = await request.json();

  if (!projectId) {
    return NextResponse.json({ error: 'projectId required' }, { status: 400 });
  }

  // Start the build in the background (don't await)
  runBuild(projectId).catch(async (err) => {
    console.error(`Build failed for ${projectId}:`, err);
    const db = getServiceSupabase();
    await db
      .from('projects')
      .update({ status: 'failed', error_log: err.message })
      .eq('id', projectId);
  });

  return NextResponse.json({ message: 'Build started' });
}

async function runBuild(projectId) {
  const db = getServiceSupabase();

  // Load project
  const { data: project } = await db
    .from('projects')
    .select('*')
    .eq('id', projectId)
    .single();

  if (!project?.requirements) {
    throw new Error('Project has no requirements');
  }

  // Step 1: Generate code with Claude
  console.log(`[${projectId}] Generating code...`);
  await db.from('projects').update({ status: 'building' }).eq('id', projectId);

  const generated = await generateCode(project.requirements);

  // Save files to Supabase
  if (generated.files?.length) {
    await db.from('project_files').delete().eq('project_id', projectId);
    await db.from('project_files').insert(
      generated.files.map(f => ({
        project_id: projectId,
        path:       f.path,
        content:    f.content,
      }))
    );
  }

  // Save file tree to project
  await db.from('projects').update({
    file_tree: generated.files?.map(f => f.path) || []
  }).eq('id', projectId);

  // Step 2: Push to GitHub
  console.log(`[${projectId}] Pushing to GitHub...`);
  const repoName = `${project.requirements.appName?.toLowerCase().replace(/[^a-z0-9]/g, '-') || 'app'}-${Date.now()}`;

  const { repoUrl, repoName: finalRepoName } = await createRepoAndPushCode(
    repoName,
    generated.files,
    project.requirements.purpose
  );

  await db.from('projects').update({ github_repo: repoUrl }).eq('id', projectId);

  // Step 3: Deploy to Vercel
  console.log(`[${projectId}] Deploying to Vercel...`);
  await db.from('projects').update({ status: 'deploying' }).eq('id', projectId);

  const { deployUrl, projectId: vercelProjectId } = await deployToVercel({
    repoName:    finalRepoName,
    projectName: repoName,
    envVars:     [] // Supabase keys are injected in vercel.js
  });

  // Done!
  console.log(`[${projectId}] Deployed: ${deployUrl}`);
  await db.from('projects').update({
    status:         'deployed',
    vercel_url:     deployUrl,
    vercel_project: vercelProjectId,
    updated_at:     new Date().toISOString()
  }).eq('id', projectId);
}
