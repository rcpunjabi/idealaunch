import { NextResponse } from 'next/server';
import { continueIntake } from '@/lib/claude';
import { getServiceSupabase } from '@/lib/supabase';

export async function POST(request) {
  try {
    const { message, conversation, projectId, userId } = await request.json();

    if (!message || !userId) {
      return NextResponse.json({ error: 'message and userId required' }, { status: 400 });
    }

    const db = getServiceSupabase();

    // Continue the conversation with Claude
    const result = await continueIntake(conversation || [], message);

    // Create or update project in Supabase
    let currentProjectId = projectId;

    if (!currentProjectId) {
      // Create new project
      const { data, error } = await db
        .from('projects')
        .insert({
          user_id:      userId,
          status:       'intake',
          conversation: result.conversation,
        })
        .select()
        .single();

      if (error) throw error;
      currentProjectId = data.id;
    } else {
      // Update existing project
      const update = {
        conversation: result.conversation,
        updated_at:   new Date().toISOString(),
      };

      if (result.requirements) {
        update.requirements = result.requirements;
        update.name         = result.requirements.appName;
        update.status       = 'requirements';
      }

      await db
        .from('projects')
        .update(update)
        .eq('id', currentProjectId);
    }

    return NextResponse.json({
      message:      result.message,
      conversation: result.conversation,
      projectId:    currentProjectId,
      done:         result.done,
      requirements: result.requirements,
    });

  } catch (err) {
    console.error('Intake API error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
