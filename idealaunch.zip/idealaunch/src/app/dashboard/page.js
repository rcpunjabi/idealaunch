'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useUser } from '@clerk/nextjs';
import { supabase } from '@/lib/supabase';

const STATUS_CONFIG = {
  intake:        { label: 'In Progress',  color: 'text-violet',   bg: 'bg-violet/10',  icon: '◉' },
  requirements:  { label: 'Reviewing',    color: 'text-yellow-400', bg: 'bg-yellow-400/10', icon: '◎' },
  building:      { label: 'Building',     color: 'text-blue-400', bg: 'bg-blue-400/10', icon: '◈' },
  deployed:      { label: 'Live',         color: 'text-emerald',  bg: 'bg-emerald/10', icon: '●' },
  failed:        { label: 'Failed',       color: 'text-red-400',  bg: 'bg-red-400/10', icon: '✕' },
};

export default function Dashboard() {
  const { user } = useUser();
  const [projects, setProjects] = useState([]);
  const [loading,  setLoading]  = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('projects')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        setProjects(data || []);
        setLoading(false);
      });
  }, [user]);

  return (
    <div className="min-h-screen bg-ink px-6 py-10 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between mb-12">
        <div>
          <div className="font-mono text-xs text-white/30 uppercase tracking-widest mb-2">
            IdeaLaunch
          </div>
          <h1 className="text-3xl font-bold text-white">
            {user?.firstName ? `Hey, ${user.firstName}.` : 'Your Apps'}
          </h1>
          <p className="text-white/40 text-sm mt-1">
            {projects.length === 0 ? "You haven't launched anything yet — let's fix that." : `${projects.length} project${projects.length !== 1 ? 's' : ''} in your portfolio.`}
          </p>
        </div>
        <Link href="/intake"
          className="px-5 py-3 rounded-xl bg-violet text-ink text-sm font-bold hover:opacity-90 transition-opacity flex items-center gap-2">
          + New App
        </Link>
      </div>

      {/* Projects grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1,2].map(i => (
            <div key={i} className="h-40 rounded-2xl shimmer" />
          ))}
        </div>
      ) : projects.length === 0 ? (
        <div className="text-center py-24 rounded-2xl border border-dashed border-surface-border">
          <div className="text-5xl mb-4">🚀</div>
          <h3 className="text-xl font-semibold mb-2">Launch your first idea</h3>
          <p className="text-white/40 text-sm mb-6">
            Describe your app in plain English. We'll handle the rest.
          </p>
          <Link href="/intake"
            className="inline-flex px-6 py-3 rounded-xl bg-violet text-ink text-sm font-bold hover:opacity-90">
            Start Building →
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {projects.map((project, i) => {
            const status = STATUS_CONFIG[project.status] || STATUS_CONFIG.intake;
            return (
              <Link
                key={project.id}
                href={`/build/${project.id}`}
                className="block rounded-2xl border border-surface-border bg-surface p-6 hover:border-violet/30 transition-all animate-fade-up"
                style={{ animationDelay: `${i * 0.05}s`, opacity: 0 }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-white text-lg">
                      {project.requirements?.appName || project.name || 'Untitled App'}
                    </h3>
                    <p className="text-sm text-white/40 mt-0.5 line-clamp-1">
                      {project.requirements?.purpose || 'Building...'}
                    </p>
                  </div>
                  <span className={`font-mono text-xs px-2 py-1 rounded-full ${status.bg} ${status.color}`}>
                    {status.icon} {status.label}
                  </span>
                </div>

                {project.vercel_url ? (
                  <div className="flex items-center gap-2 text-emerald text-xs font-mono mt-4">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald animate-pulse" />
                    {project.vercel_url.replace('https://', '')}
                  </div>
                ) : (
                  <div className="text-xs text-white/20 font-mono mt-4">
                    {new Date(project.created_at).toLocaleDateString()}
                  </div>
                )}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
