'use client';
import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUser } from '@clerk/nextjs';

export default function Intake() {
  const { user } = useUser();
  const router   = useRouter();
  const bottomRef = useRef(null);
  const inputRef  = useRef(null);

  const [messages,     setMessages]     = useState([]);
  const [input,        setInput]        = useState('');
  const [loading,      setLoading]      = useState(false);
  const [projectId,    setProjectId]    = useState(null);
  const [conversation, setConversation] = useState([]);
  const [done,         setDone]         = useState(false);
  const [requirements, setRequirements] = useState(null);

  // Kick off with greeting
  useEffect(() => {
    setMessages([{
      role: 'assistant',
      content: `Hey! I'm here to help you turn your app idea into reality. 🚀\n\nTell me — what's the app you've been thinking about building? Don't worry about technical details, just describe it like you'd explain it to a friend.`
    }]);
    setTimeout(() => inputRef.current?.focus(), 100);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const sendMessage = async (e) => {
    e?.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(m => [...m, { role: 'user', content: userMsg }]);
    setLoading(true);

    try {
      const res = await fetch('/api/intake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message:      userMsg,
          conversation,
          projectId,
          userId: user?.id
        })
      });
      const data = await res.json();

      setProjectId(data.projectId);
      setConversation(data.conversation);
      setMessages(m => [...m, { role: 'assistant', content: data.message }]);

      if (data.done && data.requirements) {
        setRequirements(data.requirements);
        setDone(true);
      }
    } catch (err) {
      setMessages(m => [...m, {
        role: 'assistant',
        content: "Sorry, something went wrong. Please try again."
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleBuild = async () => {
    router.push(`/build/${projectId}`);
  };

  return (
    <div className="min-h-screen bg-ink flex flex-col max-w-3xl mx-auto px-4">
      {/* Header */}
      <div className="py-6 flex items-center justify-between border-b border-surface-border">
        <div>
          <div className="font-mono text-xs text-white/30 uppercase tracking-widest">IdeaLaunch</div>
          <h1 className="font-semibold text-white mt-0.5">Tell me about your idea</h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald animate-pulse" />
          <span className="font-mono text-xs text-white/30">AI ACTIVE</span>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto py-8 space-y-6">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex animate-fade-up ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            style={{ animationDelay: '0s', opacity: 0 }}
          >
            {msg.role === 'assistant' && (
              <div className="w-7 h-7 rounded-full bg-violet/20 border border-violet/30 flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
                <span className="text-violet text-xs">AI</span>
              </div>
            )}
            <div className={`max-w-[85%] rounded-2xl px-5 py-4 text-sm leading-relaxed whitespace-pre-wrap ${
              msg.role === 'user'
                ? 'bg-violet/20 border border-violet/20 text-white rounded-br-sm'
                : 'bg-surface border border-surface-border text-white/80 rounded-bl-sm'
            }`}>
              {/* Strip <requirements> tags from display */}
              {msg.content.replace(/<requirements>[\s\S]*?<\/requirements>/g, '').trim()}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex items-start gap-3">
            <div className="w-7 h-7 rounded-full bg-violet/20 border border-violet/30 flex items-center justify-center flex-shrink-0">
              <span className="text-violet text-xs">AI</span>
            </div>
            <div className="bg-surface border border-surface-border rounded-2xl rounded-bl-sm px-5 py-4">
              <div className="flex gap-1">
                {[0,1,2].map(i => (
                  <span key={i} className="w-1.5 h-1.5 rounded-full bg-violet/40 animate-pulse"
                        style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Requirements preview */}
      {done && requirements && (
        <div className="mb-4 rounded-2xl border border-emerald/20 bg-emerald/5 p-5">
          <div className="font-mono text-xs text-emerald uppercase tracking-widest mb-3">
            ✓ App Blueprint Ready
          </div>
          <h3 className="font-bold text-white text-lg mb-1">{requirements.appName}</h3>
          <p className="text-white/60 text-sm mb-4">{requirements.purpose}</p>
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div>
              <div className="font-mono text-xs text-white/30 uppercase mb-1">Target User</div>
              <div className="text-sm text-white/70">{requirements.targetUser}</div>
            </div>
            <div>
              <div className="font-mono text-xs text-white/30 uppercase mb-1">Features</div>
              <div className="text-sm text-white/70">{requirements.features?.length} core features</div>
            </div>
          </div>
          <button
            onClick={handleBuild}
            className="w-full py-3 rounded-xl bg-violet text-ink font-bold text-sm hover:opacity-90 transition-opacity"
          >
            Build My App → 🚀
          </button>
        </div>
      )}

      {/* Input */}
      {!done && (
        <form onSubmit={sendMessage} className="pb-6">
          <div className="flex gap-3 items-end">
            <textarea
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
              }}
              placeholder="Describe your idea..."
              rows={1}
              className="flex-1 bg-surface border border-surface-border rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 resize-none focus:outline-none focus:border-violet/40 transition-colors"
              style={{ maxHeight: 120 }}
              disabled={loading}
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="px-4 py-3 rounded-xl bg-violet text-ink font-semibold text-sm disabled:opacity-30 hover:opacity-90 transition-opacity flex-shrink-0"
            >
              Send →
            </button>
          </div>
          <div className="font-mono text-xs text-white/20 text-center mt-3">
            ENTER to send · SHIFT+ENTER for new line
          </div>
        </form>
      )}
    </div>
  );
}
