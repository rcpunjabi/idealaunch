import { ClerkProvider } from '@clerk/nextjs';
import { Inter, Space_Mono } from 'next/font/google';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

const spaceMono = Space_Mono({
  weight: ['400', '700'],
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata = {
  title: 'IdeaLaunch — From Idea to Live App',
  description: 'Turn your app idea into a real, deployed product. No code required.',
};

export default function RootLayout({ children }) {
  return (
    <ClerkProvider>
      <html lang="en" className={`${inter.variable} ${spaceMono.variable}`}>
        <body className="bg-ink text-white antialiased">
          {children}
        </body>
      </html>
    </ClerkProvider>
  );
}
