import Link from 'next/link';
import { SignedIn, SignedOut, SignInButton } from '@clerk/nextjs';

export default function Home() {
  return (
    <main className="min-h-screen bg-ink overflow-hidden">
      {/* Background gradients */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/3 w-[600px] h-[600px] rounded-full opacity-10"
             style={{ background: 'radial-gradient(circle, #7c6fff 0%, transparent 70%)' }} />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] rounded-full opacity-8"
             style={{ background: 'radial-gradient(circle, #00e5a0 0%, transparent 70%)' }} />
      </div>

      {/* Nav */}
      <nav className="relative z-10 flex items-center justify-between px-8 py-6 max-w-6xl mx-auto">
        <div className="font-mono text-xl font-bold">
          Idea<span className="text-violet">Launch</span>
        </div>
        <div className="flex items-center gap-4">
          <SignedIn>
            <Link href="/dashboard"
              className="px-4 py-2 rounded-lg bg-violet text-ink text-sm font-semibold hover:opacity-90 transition-opacity">
              Dashboard →
            </Link>
          </SignedIn>
          <SignedOut>
            <SignInButton>
              <button className="px-4 py-2 rounded-lg border border-surface-border text-sm text-white/60 hover:text-white hover:border-violet/40 transition-all">
                Sign In
              </button>
            </SignInButton>
            <Link href="/sign-up"
              className="px-4 py-2 rounded-lg bg-violet text-ink text-sm font-semibold hover:opacity-90 transition-opacity">
              Start Free →
            </Link>
          </SignedOut>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative z-10 text-center px-6 pt-20 pb-32 max-w-4xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-violet/20 bg-violet/5 text-violet text-xs font-mono mb-8 animate-fade-up">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald animate-pulse" />
          NOW IN BETA — LIMITED SPOTS
        </div>

        <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6 animate-fade-up"
            style={{ animationDelay: '0.1s', opacity: 0 }}>
          Your idea.<br />
          <span className="gradient-text">Live in hours.</span>
        </h1>

        <p className="text-lg text-white/50 max-w-2xl mx-auto mb-10 leading-relaxed animate-fade-up"
           style={{ animationDelay: '0.2s', opacity: 0 }}>
          Describe your app idea in plain English. IdeaLaunch turns it into a real,
          working application — deployed to the web — without a single line of code from you.
        </p>

        <div className="flex items-center justify-center gap-4 animate-fade-up"
             style={{ animationDelay: '0.3s', opacity: 0 }}>
          <Link href="/sign-up"
            className="px-8 py-4 rounded-xl bg-violet text-ink font-bold text-base hover:opacity-90 transition-opacity">
            Launch My Idea →
          </Link>
          <Link href="#how-it-works"
            className="px-8 py-4 rounded-xl border border-surface-border text-white/60 text-base hover:text-white hover:border-violet/40 transition-all">
            See How It Works
          </Link>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="relative z-10 max-w-5xl mx-auto px-6 pb-32">
        <div className="text-center mb-16">
          <div className="font-mono text-xs text-white/30 uppercase tracking-widest mb-3">Process</div>
          <h2 className="text-3xl font-bold">From conversation to live URL</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            { num: '01', title: 'Describe It',   desc: 'Chat with our AI. Describe your idea in plain English — features, users, vibe.' },
            { num: '02', title: 'Review It',      desc: 'See a plain-English summary of your app. Tweak anything before building.' },
            { num: '03', title: 'Build It',       desc: 'We generate a complete Next.js application — every file, every screen.' },
            { num: '04', title: 'Launch It',      desc: 'Deployed to a live URL automatically. Your app is real. Share it today.' },
          ].map((step, i) => (
            <div key={i} className="rounded-2xl p-6 border border-surface-border bg-surface"
                 style={{ animationDelay: `${i * 0.1}s` }}>
              <div className="font-mono text-3xl font-bold text-violet/30 mb-4">{step.num}</div>
              <h3 className="font-semibold text-white mb-2">{step.title}</h3>
              <p className="text-sm text-white/40 leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="relative z-10 max-w-4xl mx-auto px-6 pb-32">
        <div className="text-center mb-16">
          <div className="font-mono text-xs text-white/30 uppercase tracking-widest mb-3">Pricing</div>
          <h2 className="text-3xl font-bold">Simple, honest pricing</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
          {[
            {
              name: 'Starter', price: '$29', period: '/mo',
              features: ['3 apps per month', 'Basic Next.js apps', 'Vercel deployment', 'GitHub repo access'],
              cta: 'Start Building', highlight: false
            },
            {
              name: 'Pro', price: '$79', period: '/mo',
              features: ['Unlimited apps', 'Complex multi-feature apps', 'Custom domains', 'Priority builds', 'Source code download'],
              cta: 'Go Pro', highlight: true
            },
          ].map((plan, i) => (
            <div key={i} className={`rounded-2xl p-8 border ${plan.highlight ? 'border-violet bg-violet/5' : 'border-surface-border bg-surface'}`}>
              <div className="font-mono text-sm text-white/40 mb-2">{plan.name}</div>
              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-4xl font-bold">{plan.price}</span>
                <span className="text-white/40">{plan.period}</span>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((f, j) => (
                  <li key={j} className="flex items-center gap-2 text-sm text-white/60">
                    <span className="text-emerald text-xs">✓</span> {f}
                  </li>
                ))}
              </ul>
              <Link href="/sign-up"
                className={`block text-center py-3 rounded-xl font-semibold text-sm transition-opacity hover:opacity-90 ${
                  plan.highlight ? 'bg-violet text-ink' : 'border border-surface-border text-white/60 hover:text-white'
                }`}>
                {plan.cta} →
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-surface-border px-8 py-8 max-w-6xl mx-auto">
        <div className="flex items-center justify-between text-white/30 text-sm">
          <div className="font-mono">IdeaLaunch</div>
          <div>Built with Claude · Deployed on Vercel</div>
        </div>
      </footer>
    </main>
  );
}
