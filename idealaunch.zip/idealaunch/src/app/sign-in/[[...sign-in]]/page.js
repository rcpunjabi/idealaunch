import { SignIn } from '@clerk/nextjs';

export default function SignInPage() {
  return (
    <div className="min-h-screen bg-ink flex items-center justify-center px-4"
         style={{ backgroundImage: 'radial-gradient(ellipse at 50% 0%, rgba(124,111,255,0.08) 0%, transparent 60%)' }}>
      <div>
        <div className="text-center mb-8">
          <div className="font-mono text-2xl font-bold mb-2">
            Idea<span className="text-violet">Launch</span>
          </div>
          <div className="font-mono text-xs text-white/30 uppercase tracking-widest">
            Welcome back
          </div>
        </div>
        <SignIn
          appearance={{
            variables: {
              colorPrimary:    '#7c6fff',
              colorBackground: '#12121e',
              colorText:       '#e8e8f0',
              colorInputBackground: '#1a1a2a',
              colorInputText:  '#e8e8f0',
              borderRadius:    '12px',
              fontFamily:      'Inter, sans-serif',
            }
          }}
        />
      </div>
    </div>
  );
}
