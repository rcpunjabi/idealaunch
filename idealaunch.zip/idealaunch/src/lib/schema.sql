-- Run this in your Supabase SQL editor to create all tables.

-- Projects table: one row per app a user is building
CREATE TABLE IF NOT EXISTS projects (
  id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id         TEXT NOT NULL,           -- Clerk user ID
  name            TEXT,
  status          TEXT DEFAULT 'intake'    -- intake | requirements | building | deployed | failed
                    CHECK (status IN ('intake','requirements','building','deployed','failed')),
  conversation    JSONB DEFAULT '[]',      -- Full Claude conversation history
  requirements    JSONB,                   -- Structured requirements JSON
  file_tree       JSONB,                   -- Generated file tree
  github_repo     TEXT,                    -- GitHub repo URL
  vercel_url      TEXT,                    -- Live deployment URL
  vercel_project  TEXT,                    -- Vercel project ID
  error_log       TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Subscriptions table: Stripe billing
CREATE TABLE IF NOT EXISTS subscriptions (
  id                  UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id             TEXT UNIQUE NOT NULL,
  stripe_customer_id  TEXT UNIQUE,
  stripe_sub_id       TEXT UNIQUE,
  plan                TEXT DEFAULT 'free' CHECK (plan IN ('free','starter','pro')),
  status              TEXT DEFAULT 'active',
  current_period_end  TIMESTAMPTZ,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Generated files table: stores all code files per project
CREATE TABLE IF NOT EXISTS project_files (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id  UUID REFERENCES projects(id) ON DELETE CASCADE,
  path        TEXT NOT NULL,
  content     TEXT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE projects       ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions  ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_files  ENABLE ROW LEVEL SECURITY;

-- RLS policies: users can only see their own data
CREATE POLICY "projects_own" ON projects
  FOR ALL USING (user_id = auth.jwt() ->> 'sub');

CREATE POLICY "subscriptions_own" ON subscriptions
  FOR ALL USING (user_id = auth.jwt() ->> 'sub');

CREATE POLICY "project_files_own" ON project_files
  FOR ALL USING (
    project_id IN (
      SELECT id FROM projects WHERE user_id = auth.jwt() ->> 'sub'
    )
  );

-- Index for faster queries
CREATE INDEX idx_projects_user_id ON projects(user_id);
CREATE INDEX idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX idx_project_files_project_id ON project_files(project_id);
